const express = require("express");
const cors = require("cors");
const mysql = require("mysql2/promise");

const db = require("./db"); 

const app = express();

app.use(express.json());
app.use(cors());



app.get("/usuario", async (req, res) => {
    try {
        const [lista] = await db.query("SELECT * FROM usuario");
        res.json(lista);
    } catch (e) {
        res.status(500).json(erro);
    }
});

app.post("/cadastro", async (req, res) => {
    try {
        const {
            nome,
            cpf,
            sexo,
            dtnasc,
            estcivil,
            email,
            telefone,
            senha
        } = req.body;

        const [resultado] = await db.query(
            "INSERT INTO usuario (nome, cpf, sexo, dtnasc, estcivil, email, telefone, senha) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            [nome, cpf, sexo, dtnasc, estcivil, email, telefone, senha]
        );

        res.json({
            id: resultado.insertId,
            nome,
            cpf,
            email
        });

    } catch (erro) {
            console.error("ERRO MYSQL:", erro);
            res.status(500).json({ erro: erro.message });
        }
    }
);
app.listen(3248, () => {
    console.log("API ESTÁ RODANDO NA PORTA http://localhost:3248")
})