$(document).ready(function() {

    $(".register-container")
        .hide()
        .fadeIn(1200);

    $("#cadastrar").click(async function () {


        const dados = {
            nome: $("#nome").val(),
            cpf: $("#cpf").val(),
            email: $("#email").val(),
            senha: $("#senha").val(),
            confsenha: $("#confiSenha").val(),
            sexo: $("input[name='sexo']:checked").val(),
            dtnasc: $("#dtNasc").val(),
            estcivil: $("#estCivil").val(),
            telefone: $("#tel").val()
            
        };

        let tercond = $("#terCond").is(":checked");

        $("#mensagem").hide();

        if (Object.values(dados).some(valor => !valor)) {

            $("#mensagem")
                .removeClass("sucesso")
                .addClass("erro")
                .text("Preencha todos os campos")
                .fadeIn(500);

            $(".register-container")
                .animate({ marginLeft: "-10px" }, 100)
                .animate({ marginLeft: "10px" }, 100)
                .animate({ marginLeft: "-10px" }, 100)
                .animate({ marginLeft: "10px" }, 100)
                .animate({ marginLeft: "0px" }, 100);
                
            return;

        } 
        
        if (dados.senha !== dados.confsenha) {

            $("#mensagem")
                .removeClass("sucesso")
                .addClass("erro")
                .text("As senhas não coincidem")
                .fadeIn(500);

            $(".register-container")
                .animate({ marginLeft: "-10px" }, 100)
                .animate({ marginLeft: "10px" }, 100)
                .animate({ marginLeft: "-10px" }, 100)
                .animate({ marginLeft: "10px" }, 100)
                .animate({ marginLeft: "0px" }, 100);
                return;

        } 
        if (!tercond){

            $("#mensagem")
            .removeClass("sucesso")
            .addClass("erro")
            .text("Você precisa aceitar os termos")
            .fadeIn(500);
            return;

        } 

        try {

            $("#cadastrar").text("Cadastrando...");
        
            const resposta = await fetch("http://localhost:3248/cadastro", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(dados)
            });
        
            const resultado = await resposta.json();
        
            if (!resposta.ok) {
                throw new Error(resultado.message || "Erro no cadastro");
            }
        
            $("#mensagem")
                .removeClass("erro")
                .addClass("sucesso")
                .text("Cadastro realizado com sucesso!")
                .fadeIn(500);
        
            $("#cadastrar").text("Cadastrar");
        
        } catch (erro) {
        
            console.error(erro);
        
            $("#mensagem")
                .removeClass("sucesso")
                .addClass("erro")
                .text("Erro ao enviar os dados")
                .fadeIn(500);
        
            $("#cadastrar").text("Cadastrar");
        }

    });

    $("#voltar").click(function () {
        window.location.href = "../login/login.html";
    });

});