$(document).ready(function () {
    $(".card").eq(0).fadeIn(500, function () {
        $(".card").eq(1).fadeIn(500, function (){
            $(".card").eq(2).fadeIn(500, function (){
                $(".parte-perfil").fadeIn(600, function (){
                    $(".parte-mensagem").fadeIn(600);
                });
            });
        });
    });

    //clique no menu

    $(".menu ul li").click(function (){
        $(".menu ul li").removeClass("ativo");
        $(this).addClass("ativo");

        let pagina = $(this).data("pagina");

        $(".conteudo-pagina").hide();
        $(".mensagem").hide();

        if(pagina === "home") {
            $("#homeSection").fadeIn(300);
        } else if (pagina === "perfil") {
            $("#perfilSection").fadeIn(300);
        } else if (pagina === "mensagens") {
            $("#mensagensSection").fadeIn(300, function () {
                $(".mensagem").each(function (index) {
                    $(this).delay(index * 200).fadeIn(300);
                });
            });
        };
    });

    //efeito ao clicar nos cards

    $(".card").click(function () {
        $(this).fadeOut(150).fadeIn(150);
    });
    
      // destacar mensagem clicada
    $(".mensagem-item").click(function () {
        $(".mensagem-item").removeClass("ativa");
        $(this).addClass("ativa");
    });
});



